const express = require('express');
var http = require("http");
const app = express();
const mongoose = require('mongoose');

const bodyParser = require('body-parser');


var server = http.createServer(app);
mongoose.connect("mongodb://127.0.0.1:27017/Users",{useNewUrlParser:true}).then(()=>{console.log('Database is connected')},err => {console.log("Error in connecting" + err)});

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

server.listen(5000, function(){
  console.log('Server is running on Port: ');
});