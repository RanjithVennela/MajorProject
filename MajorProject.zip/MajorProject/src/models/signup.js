var mongoose = require('mongoose');

var signupSchema = mongoose.Schema({
    firstName:{type:String,required:true},
    lastName:{type:String,required:true},
    mobile:{type:Number,required:true},
    Email:{type:String,required:true},
    Password:{type:String,required:true}
})

module.exports = mongoose.mopdel('User',signupSchema);