// var mongoose = require('mongoose');

// var signinSchema = mongoose.Schema({
//     userEmail:{type:String,required:true},
//     userPassword:{type:String,required:true}
// })

// module.exports = mongoose.model("User",signinSchema);
