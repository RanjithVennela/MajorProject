import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import Form from './components/form';
import App from './App';
import { BrowserRouter as Router, Route } from 'react-router-dom';

ReactDOM.render(<App/>, document.getElementById('root'));

