import React from 'react';

import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
class Home extends React.Component {
    render() {
        return (
            <div>
                <div className="row">
                        <button className="btn btn-info"><Link to="/">Home</Link></button> 
                        <button className="btn btn-info"> <Link to="/signin">SignIn</Link></button>
                        <button className="btn btn-info"><Link to="/signup">SignUp</Link></button>
                </div>
            </div >
        )
    }
}

export default Home;