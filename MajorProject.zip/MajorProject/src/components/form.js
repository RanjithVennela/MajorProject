import React, { Component } from 'react';

class Form extends React.Component {

    constructor(){
        super();
        this.state={
            firstName:'',
            lastName:'',
            mobile:'',
            email:'',
            password:'',
            isLoggedin:false
        }
    }
    handleChange=(event)=>{
        event.preventDefault();
        switch(event.target.name)
        {
            case "firstName"    :   this.setState({firstName:event.target.value});
                                    break;
            case "lastName"     :   this.setState({lastName:event.target.value});
                                    break;
            case "mobile"       :   this.setState({mobile:event.target.value});
                                    break;
            case "email"        :   this.setState({email:event.target.value});
                                    break;                                    
            case "password"     :   this.setState({password:event.target.value});
                                    break;
        }
    }
    
    // signUp =  ()=>{
    //    <Body/>
    // }

    render() {
        return (
            <div>
                <label className="control-label">Registration Form</label>
                <form onSubmit={this.handleSubmit}>
                    <div className="row">
                        <div className="col-md-4 col-md-offset-2">
                            <div className="form-group">
                                <label className="control-label">FirstName</label>
                                <input type="text" name="firstName" value={this.state.firstName} onChange={this.handleChange} className="form-control" placeholder="FirstName" />
                            </div>
                            <div className="form-group">
                                <label className="control-label">LastName</label>
                                <input type="text" name="lastName" value={this.state.lastName} onChange={this.handleChange} className="form-control" placeholder="LastName" />
                            </div>

                            <div className="form-group">
                                <label className="control-label">Mobile Number</label>
                                <input type="number" name="mobile" value={this.state.mobile} onChange={this.handleChange} className="form-control" placeholder="MobileNumber" />
                            </div>

                            <div className="form-group">
                                <label className="control-label">Email</label>
                                <input type="email" name="email" value={this.state.mail} onChange={this.handleChange} className="form-control" placeholder="E-mail Id" />
                            </div>
                            <div className="form-group">
                                <label className="control-label">Password</label>
                                <input type="password" name="password" value={this.state.password} onChange={this.handleChange} className="form-control" placeholder="Password" />
                            </div>
                            <div className="row">
                                <div className="col-md-10">
                                    <button className="btn btn-info" onClick="signUp()">SignUp</button>
                                </div>
                                <div className="col-md-2">
                                    <button className="btn btn-info">SignIn</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        )
    }
}


export default Form;