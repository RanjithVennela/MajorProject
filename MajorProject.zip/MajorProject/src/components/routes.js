import React from 'react';
import Home from './Home';
import SignIn from './signinForm'
import SignUp from './signupForm'
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';


class Routes extends React.Component {
    render() {
        return (
            <Router>
                <Switch>
                    <Route exact path="/" component={Home} />
                    <Route path="/signin" component={SignIn} />
                    <Route path="/signup" component={SignUp} />
                </Switch>
            </Router>
        )
    }
}

export default Routes;