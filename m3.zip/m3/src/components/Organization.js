import React from "react"
import axios from "axios"
import {Link} from "react-router-dom"
class Organization extends React.Component {

    constructor() {
        super();
        this.state = {
            name: "",
            mobile: "",
            email: '',
            password: '',
            flag:false
        }
    }

    handleChange = (event) => {
        event.preventDefault();
        this.setState({
            flag: false
        })
        switch (event.target.name) {
            case "name": this.setState({ name: event.target.value });
                break;
            case "mobile": this.setState({ mobile: event.target.value });
                break;
            case "email": this.setState({ email: event.target.value });
                break;
            case "password": this.setState({ password: event.target.value });
                break;
        }
    }

    handleSubmit = async (event) => {
        event.preventDefault();
    
        const res = await axios.get("http://localhost:4200/serverport/");
    
        const user = {
          name: this.state.name,
          mobile: this.state.mobile,
          email: this.state.email,
          password: this.state.password,
        }
        res.data.forEach(element => {
          if (element.email === user.email) {
            alert("email exists");
            this.setState({
              flag: true
            })
          }
        });
        if (this.state.flag === false) {
          axios.post("http://localhost:4200/serverport/add", user).then(res => console.log(res.data));
          this.setState({
    
            name: '',
            mobile: '',
            email: '',
            password: '',
          })
    
        }
    
      }
    

    render() {
        return (
            <div>
                <div>
                    <nav className="navbar navbar-inverse">
                        <div className="container-fluid">
                            <div className="navbar-header">
                                <Link to="/" className="navbar-brand">Home</Link>
                            </div>

                            <ul className="nav navbar-nav navbar-center">
                                <li className="navbar-text">Organization Page</li>
                            </ul>
                        </div>
                    </nav>
                </div>
                <form onSubmit={this.handleSubmit}>
                    <label className="control-label">SignUp Form</label>
                    <div className="row">
                        <div className="col-md-4 col-md-offset-2">
                            <div className="form-group">
                                <label className="control-label">Email</label>
                                <input type="string" value={this.state.name} onChange={this.handleChange} name="name" className="form-control" placeholder="Organization Name" required />
                            </div>
                            <div className="form-group">
                                <label className="control-label">Mobile Number</label>
                                <input type="number" name="mobile" value={this.state.mobile} onChange={this.handleChange} className="form-control" placeholder="MobileNumber" />
                            </div>
                            <div className="form-group">
                                <label className="control-label">Email</label>
                                <input type="email" value={this.state.email} onChange={this.handleChange} name="email" className="form-control" placeholder="E-mail Id" required />
                            </div>
                            <div className="form-group">
                                <label className="control-label">Password</label>
                                <input type="password" value={this.state.password} onChange={this.handleChange} name="password" className="form-control" placeholder="Password" required />
                            </div>

                            <div className="col-md-12">
                                <button className="btn btn-info" >Register</button>
                            </div>

                        </div>
                    </div>
                </form>
            </div>
        )

    }
}

export default Organization;