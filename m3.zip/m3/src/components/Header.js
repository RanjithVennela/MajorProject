import React from "react";
import { Link } from 'react-router-dom';
class Header extends React.Component {
    render() {
        return (
            <div>
                <nav className="navbar navbar-inverse">
                    <div className="container-fluid">
                        <div className="navbar-header">
                        <Link to="/" className="navbar-brand">Home</Link>
                        </div>
                        <ul className="nav navbar-nav navbar-right">
                            <li><Link to="/signin"><span className="glyphicon glyphicon-user"></span> SignIn</Link></li>
                            <li><Link to="/signup"><span className="glyphicon glyphicon-log-in"></span> SignUp</Link></li>
                        </ul>
                    </div>
                </nav>
            </div>
        )
    }
}

export default Header;