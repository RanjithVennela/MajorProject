import React from 'react';
import { Link,Redirect } from 'react-router-dom';
import axios from 'axios';
import User from "./User"
const MyContext = React.createContext();
class loginForm extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      password: '',
      flag: false,
      flag1: false,
      break1: false,
      isLoggedin:false,
      user1:{}
    }
  }


  handleChange = (event) => {
    event.preventDefault();
    this.setState({
      flag: false,
      flag1: false
    })
    switch (event.target.name) {
      case "email": this.setState({ email: event.target.value })
        break;
      case "password": this.setState({ password: event.target.value })
        break;
    }
  }

  handleSubmit = async (event) => {
    event.preventDefault();
    const res = await axios.get("http://localhost:4200/serverport/");
    const user = {
      email: this.state.email,
      password: this.state.password
    }
    res.data.forEach(element => {
      if (element.email === user.email) {
        console.log("hello");
        this.setState({
          break1: true,
          flag:false
        })
        if (user.password != element.password) {
          this.setState({
            flag1: true
          })
        }
        else
        {
          this.setState({
            user1:element
          })
        }
      }
      else if (element.email != user.email && this.state.break1 == false) {
        console.log("hi")
        this.setState({
          flag: true
        })
      }
    });
    if (this.state.flag == true) {
      alert("Email Doesn't Exist")
    }
    else if (this.state.flag1 == true) {
      alert("Email Or Password Is Incorrect")
    }
    else if(this.state.flag === false && this.state.flag1 === false)
    {
      this.setState({
        isLoggedin:true
      })
      
      this.props.history.push({pathname:"/user",state:{detail:this.state.user1}});
      
    }
  }
  render() {
    return (
      <div>
        <div>
          <nav className="navbar navbar-inverse">
            <div className="container-fluid">
              <div className="navbar-header">
                <Link to="/" className="navbar-brand">Home</Link>
              </div>
            
            <ul className="nav navbar-nav navbar-center">
              <li  className="navbar-text">SignIn Page</li>
              </ul>
              </div>
          </nav>
        </div>
        <form onSubmit={this.handleSubmit}>
          <label className="control-label">Login Form</label>
          <div className="row">
            <div className="col-md-4 col-md-offset-2">
              <div className="form-group">
                <label className="control-label">Email</label>
                <input type="email" value={this.state.email} onChange={this.handleChange} name="email" className="form-control" placeholder="E-mail Id" required/>
              </div>
              <div className="form-group">
                <label className="control-label">Password</label>
                <input type="password" value={this.state.password} onChange={this.handleChange} name="password" className="form-control" placeholder="Password" required/>
              </div>
           
                <div className="col-md-12">
                  <button className="btn btn-info" >SignIn</button>
                </div>
          
            </div>
          </div>
        </form>
        {/* <MyContext.Provider value={this.state.isLoggedin}>
          <User />
        </MyContext.Provider> */}
      </div>
    )
  }
}

export default loginForm;