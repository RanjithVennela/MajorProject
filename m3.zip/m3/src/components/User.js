import React from "react";
import { Route,Link } from "react-router-dom";
import Profile from "./Profile";
class User extends React.Component {
    constructor() {
        super();
        this.state = {
            user: {}
        }
    }
    componentDidMount() {

        console.log(this.props.location.state.detail.email);
        this.setState({ user: this.props.location.state.detail });
    }

    render() {
        return (
            <div>
                <div>
                    <div>
                        <nav className="navbar navbar-inverse">
                            <div className="container-fluid">
                                <div className="navbar-header">
                                    <Link to="/" className="navbar-brand">Home</Link>
                                </div>

                                <ul className="nav navbar-nav navbar-right">
                                    <li className="dropdown">
                                        <a className="dropdown-toggle" data-toggle="dropdown" href="#">
                                        <span className="glyphicon glyphicon-user"></span> 
                                            <span className="caret"></span></a>
                                        <ul className="dropdown-menu">
                                            <li><Link to="/user/profile">Profile</Link></li>
                                            <li><a href="#">Notification</a></li>
                                        </ul>
                                    </li>
                                    <li><Link to="/"> <span className="glyphicon glyphicon-log-out"></span> Logout</Link></li>
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
                <div>
                   <Route value={this.state.user} component={Profile}/>
                </div>
            </div>)
    }
}

export default User;