import React from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
class signupForm extends React.Component {

  constructor() {
    super();
    this.state = {
      firstName: '',
      lastName: '',
      mobile: '',
      email: '',
      password: '',
      flag: false,
      persons: [],

    }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }


  handleChange = (event) => {
    event.preventDefault();
    this.setState({
      flag: false
    })
    switch (event.target.name) {
      case "firstName": this.setState({ firstName: event.target.value });
        break;
      case "lastName": this.setState({ lastName: event.target.value });
        break;
      case "mobile": this.setState({ mobile: event.target.value });
        break;
      case "email": this.setState({ email: event.target.value });
        break;
      case "password": this.setState({ password: event.target.value });
        break;
    }
  }

  handleSubmit = async (event) => {
    event.preventDefault();

    const res = await axios.get("http://localhost:4200/serverport/");

    const user = {
      firstName: this.state.firstName,
      lastName: this.state.lastName,
      mobile: this.state.mobile,
      email: this.state.email,
      password: this.state.password,
    }
    res.data.forEach(element => {
      if (element.email === user.email) {
        alert("email exists");
        this.setState({
          flag: true
        })
      }
    });
    if (this.state.flag === false) {
      axios.post("http://localhost:4200/serverport/add", user).then(res => console.log(res.data));
      this.setState({

        firstName: '',
        lastName: '',
        mobile: '',
        email: '',
        password: '',
      })

    }

  }



  render() {
    return (
      <div>
        <div>
          <nav className="navbar navbar-inverse">
            <div className="container-fluid">
              <div className="navbar-header">
                <Link to="/" className="navbar-brand">Home</Link>
              </div>
            
            <ul className="nav navbar-nav navbar-center">
              <li  className="navbar-text">SignUp Page</li>
              </ul>
              </div>
          </nav>
        </div>
        <form onSubmit={this.handleSubmit}>
          <label className="control-label">Registration Form</label>
          <div className="row">
            <div className="col-md-4 col-md-offset-2">
              <div className="form-group">
                <label className="control-label">FirstName</label>
                <input type="text" name="firstName" value={this.state.firstName} onChange={this.handleChange} className="form-control" placeholder="FirstName" required/>
              </div>
              <div className="form-group">
                <label className="control-label">LastName</label>
                <input type="text" name="lastName" value={this.state.lastName} onChange={this.handleChange} className="form-control" placeholder="LastName" required/>
              </div>

              <div className="form-group">
                <label className="control-label">Mobile Number</label>
                <input type="number" name="mobile" value={this.state.mobile} onChange={this.handleChange} className="form-control" placeholder="MobileNumber" required/>
              </div>

              <div className="form-group">
                <label className="control-label">Email</label>
                <input type="email" name="email" value={this.state.email} onChange={this.handleChange} className="form-control" placeholder="E-mail Id" required/>
              </div>
              <div className="form-group">
                <label className="control-label">Password</label>
                <input type="password" name="password" value={this.state.password} onChange={this.handleChange} className="form-control" placeholder="Password" required/>
              </div>
              <div className="row">
                <div className="col-md-6">
                  <Link to="/organization"><button className="btn btn-info">Organization</button></Link>
                </div >
                <div className="col-md-6">
                  <button className="btn btn-info" type="submit">Register</button>
                </div>

              </div>
            </div>
          </div>
        </form>
      </div>
    )
  }
}

export default signupForm;