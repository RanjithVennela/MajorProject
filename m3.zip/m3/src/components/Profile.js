import React from "react";

class Profile extends React.Component
{
    render(){
        return(<div>
            Hello
            {console.log(this.props.value)}
        </div>)
    }
}

export default Profile;