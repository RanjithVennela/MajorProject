import React from 'react';
import Home from './Home';
import SignIn from './signinForm'
import SignUp from './signupForm'
import Organization from './Organization'
import User from "./User";
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';


class Routes extends React.Component {
    render() {
        return (
            <Router>
                <Switch>
                    <Route exact path="/" component={Home} />
                    <Route path="/signin" component={SignIn} />
                    <Route path="/signup" component={SignUp} />
                    <Route path="/organization" component={Organization} />
                    <Route path="/user" component={User} />
                </Switch>
            </Router>
        )
    }
}

export default Routes;