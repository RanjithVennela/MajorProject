import React from "react";
import { Link } from 'react-router-dom';
class Footer extends React.Component {
    render() {
        return (
            <div>
                <nav className="navbar navbar-default navbar-fixed-bottom navbar-inverse">
                    <div className="container-fluid">
                        <ul className="nav navbar-nav">
                            <li><a> About </a></li>
                            <li><a>Terms & Conditions</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
        )
    }
}

export default Footer;