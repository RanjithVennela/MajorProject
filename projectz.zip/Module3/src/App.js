import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import './App.css';
import Form from './components/signupForm'
class App extends Component {

  constructor() {
    super();
    this.state = {

      email: '',
      password: '',
      firstName: '',
      lastName: '',
      mobile: '',
      isLoggedin: false
    }
  }

  auth = () => {
    this.setState({
      isLoggedin: true
    })
  }

  register = () => {
    console.log("Hi this is signup form")
    this.setState({
      isLoggedin: false
    })
  }
  signin = () => {
    console.log("Hi this is signin form");
  }

  signupForm = () => {
    return (
      <form>
        <label className="control-label">Registration Form</label>
        <div className="row">
          <div className="col-md-4 col-md-offset-2">
            <div className="form-group">
              <label className="control-label">FirstName</label>
              <input type="text" name="firstName" value={this.state.firstName} onChange={this.handleChange} className="form-control" placeholder="FirstName" />
            </div>
            <div className="form-group">
              <label className="control-label">LastName</label>
              <input type="text" name="lastName" value={this.state.lastName} onChange={this.handleChange} className="form-control" placeholder="LastName" />
            </div>

            <div className="form-group">
              <label className="control-label">Mobile Number</label>
              <input type="number" name="mobile" value={this.state.mobile} onChange={this.handleChange} className="form-control" placeholder="MobileNumber" />
            </div>

            <div className="form-group">
              <label className="control-label">Email</label>
              <input type="email" name="email" value={this.state.email} onChange={this.handleChange} className="form-control" placeholder="E-mail Id" />
            </div>
            <div className="form-group">
              <label className="control-label">Password</label>
              <input type="password" name="password" value={this.state.password} onChange={this.handleChange} className="form-control" placeholder="Password" />
            </div>
            <div className="row">
              <div className="col-md-10">
                <button className="btn btn-info" onClick={this.register}>Register</button>
              </div>

            </div>
          </div>
        </div>
      </form>
    )
  }


  loginForm = () => {
    return (
      <div>
        <form >
          <label className="control-label">Login Form</label>
          <div className="row">
            <div className="col-md-4 col-md-offset-2">
              <div className="form-group">
                <label className="control-label">Email</label>
                <input type="email" name="email" value={this.state.email} onChange={this.handleChange} className="form-control" placeholder="E-mail Id" />
              </div>
              <div className="form-group">
                <label className="control-label">Password</label>
                <input type="password" name="password" value={this.state.password} onChange={this.handleChange} className="form-control" placeholder="Password" />
              </div>
              <div className="row">
                <div className="col-md-10">
                  <button className="btn btn-info" onClick={this.auth}> Signup </button>
                </div>
                <div className="col-md-2">
                  <button className="btn btn-info" onClick={this.signin}>SignIn</button>
                </div>
              </div>
            </div>
          </div>
        </form>

      </div>

    )
  }

  handleChange = (event) => {
    event.preventDefault();
    if (this.state.isLoggedin) {
      switch (event.target.name) {
        case "firstName": this.setState({ firstName: event.target.value });
          break;
        case "lastName": this.setState({ lastName: event.target.value });
          break;
        case "mobile": this.setState({ mobile: event.target.value });
          break;
        case "email": this.setState({ email: event.target.value });
          break;
        case "password": this.setState({ password: event.target.value });
          break;
      }
    }
    else {
      switch (event.target.name) {
        case "email": this.setState({ email: event.target.value })
          break;
        case "password": this.setState({ password: event.target.value })
          break;
      }
    }

  }

  render() {
    return (
      // <div>
      //   {/* {this.state.isLoggedin === false ? this.loginForm() : this.signupForm()} */}
      // </div>
      <Router>
        <div>
          <button><Link to="/">signin</Link></button>
          <button><Link to="/register">signup</Link></button>
          <Route exact path="/" component={Form} />
        </div>
      </Router>
    );
  }
}

export default App;
