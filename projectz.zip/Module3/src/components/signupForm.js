import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
import axios from 'axios';
class signupForm extends React.Component {

  constructor() {
    super();
    this.state = {
      firstName: '',
      lastName: '',
      mobile: '',
      email: '',
      password: '',
    }
  }


  handleChange = (event) => {
    event.preventDefault();
      switch (event.target.name) {
        case "firstName": this.setState({ firstName: event.target.value });
          break;
        case "lastName": this.setState({ lastName: event.target.value });
          break;
        case "mobile": this.setState({ mobile: event.target.value });
          break;
        case "email": this.setState({ email: event.target.value });
          break;
        case "password": this.setState({ password: event.target.value });
          break;
      }
    }
    
    handleSubmit = (event)=>{
      event.preventDefault();
      const user = {
        firstName: this.state.firstName,
        lastName: this.state.lastName,
        mobile: this.state.mobile,
        email: this.state.email,
        password: this.state.password,   
      }
      console.log(user);
      axios.post("http://localhost:4200/serverport/add",user).then(res => console.log(res.data));
      this.setState({

        firstName: '',
        lastName: '',
        mobile: '',
        email: '',
        password: '',  
      })
    }
    

  render() {
    return (
      <div>
        <form onSubmit={this.handleSubmit}>
          <label className="control-label">Registration Form</label>
          <div className="row">
            <div className="col-md-4 col-md-offset-2">
              <div className="form-group">
                <label className="control-label">FirstName</label>
                <input type="text" name="firstName" value={this.state.firstName} onChange={this.handleChange} className="form-control" placeholder="FirstName" />
              </div>
              <div className="form-group">
                <label className="control-label">LastName</label>
                <input type="text" name="lastName" value={this.state.lastName} onChange={this.handleChange} className="form-control" placeholder="LastName" />
              </div>

              <div className="form-group">
                <label className="control-label">Mobile Number</label>
                <input type="number" name="mobile" value={this.state.mobile} onChange={this.handleChange} className="form-control" placeholder="MobileNumber" />
              </div>

              <div className="form-group">
                <label className="control-label">Email</label>
                <input type="email" name="email" value={this.state.email} onChange={this.handleChange} className="form-control" placeholder="E-mail Id" />
              </div>
              <div className="form-group">
                <label className="control-label">Password</label>
                <input type="password" name="password" value={this.state.password} onChange={this.handleChange} className="form-control" placeholder="Password" />
              </div>
              <div className="row">
                <div className="col-md-10">
                  <button className="btn btn-info" type="submit">Register</button>
                </div>

              </div>
            </div>
          </div>
        </form>
        <div className="row">
          <div className="col-md-4 col-md-offset-2">
            Home Page :
        <button className="btn btn-info"><Link to="/">Home</Link></button>
          </div>
        </div>
      </div>
    )
  }
}

export default signupForm;