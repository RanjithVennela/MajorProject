import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';
class loginForm extends React.Component {

  render() {
    return (
      <div>
        <form >
          <label className="control-label">Login Form</label>
          <div className="row">
            <div className="col-md-4 col-md-offset-2">
              <div className="form-group">
                <label className="control-label">Email</label>
                <input type="email" name="email" className="form-control" placeholder="E-mail Id" />
              </div>
              <div className="form-group">
                <label className="control-label">Password</label>
                <input type="password" name="password" className="form-control" placeholder="Password" />
              </div>
              <div className="row">
                <div className="col-md-10">
                  <button className="btn btn-info" > Signup </button>
                </div>
                <div className="col-md-2">
                  <button className="btn btn-info" >SignIn</button>
                </div>
              </div>
            </div>
          </div>
        </form>
        <br />
        <div className="row">
          <div className="col-md-4 col-md-offset-2">
            Home Page :
          <button className="btn btn-info"><Link to="/">Home</Link></button>
          </div>
        </div>
      </div>

    )
  }
}

export default loginForm;