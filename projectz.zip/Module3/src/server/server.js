const express = require('express');
const app = express();
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const Users = require("../server/signupRouter");


mongoose.connect("mongodb://127.0.0.1:27017/Users",{useNewUrlParser:true}).then(()=>{console.log('Database is connected')},err => {console.log("Error in connecting" + err)});
app.use(cors());
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());
app.use("/signup",Users);
app.listen(4200, function(){
  console.log('Server is running on Port: ');
});