const express = require("express");
var router = express.Router();
const Users = require('../models/signup');
router.route('/add').post((req,res)=>{
    const user = new Users(req.body);
    user.save().then(user => res.json("Added successfully")).catch(err=>res.status(400).send("data not added to databane"));
})
module.exports = Users;