// ServerPort.js

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// Define collection and schema for Items
var ServerPort = new Schema({
  firstName:{type:String},
  lastName:{type:String},
  mobile:{type:Number},
  email:{type:String},
  password:{type:String}},
  {
    collection: 'servers'
});

module.exports = mongoose.model('ServerPort', ServerPort);